//
//  RadioView.m
//  BoJio
//
//  Created by KMI-IOS1 on 08/09/15.
//  Copyright (c) 2015 kminfosystems. All rights reserved.
//

#import "RadioView.h"

#define CELL_H_PAD  45
#define CELL_H_PHONE  25

UIButton *btn;
UILabel *menu_lbl;
UIImageView *chkimg ;
@implementation RadioView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.


- (void)drawRect:(CGRect)rect
{

    self.optTableView=[[UITableView alloc]initWithFrame:rect style:UITableViewStylePlain];
    self.optTableView.backgroundColor=[UIColor colorWithRed:CREAME_R green:CREAME_G blue:CREAME_B alpha:1.0];
  //  self.optTableView.backgroundColor=[UIColor greenColor];
    self.optTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.optTableView.scrollEnabled=FALSE;
    [self createmenuForTableView];
    [self addSubview:self.optTableView];
    self.backgroundColor =[UIColor whiteColor];
}//

- (void) createmenuForTableView
{
     self.optTableView.dataSource=self;
     self.optTableView.delegate=self;
     self.Items = [NSMutableArray arrayWithObjects:@"Everyone",@"Friends of friend",@"Friends",@"Customized groups", nil];
    
    
}




-(void)initWithFrameAndTableViewDataArray:(NSMutableArray *)menuArr
{
    self.Items=menuArr;
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.Items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    
    
    NSString *cellIdentifier = @"MenuItemCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    else{
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
   
    btn=[UIButton buttonWithType:UIButtonTypeCustom];
    btn.tag=444+indexPath.row;
    [btn addTarget:self action:@selector(radioGroupCheck:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor=[UIColor clearColor];
    
    
    
    chkimg=[[UIImageView alloc]init];  //,WithFrame:CGRectMake(2, (cell.contentView.frame.size.height-16)/2, 15, 15)];

    menu_lbl= [[UILabel alloc] init];
    menu_lbl.textAlignment= NSTextAlignmentJustified;
    menu_lbl.text=[self.Items objectAtIndex:indexPath.row];
    
    menu_lbl.textColor=[UIColor colorWithRed:GRAY_R green:GRAY_G blue:GRAY_B alpha:0.5];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
            menu_lbl.font = [UIFont fontWithName:FONT size:25];
    }
    else
    {
        menu_lbl.font = [UIFont fontWithName:FONT size:13];
    }

   // menu_lbl.font = [UIFont fontWithName:FONT size:13];
    menu_lbl.backgroundColor=[UIColor clearColor];
    
    
    

//    
//    cell.textLabel.backgroundColor=[UIColor orangeColor];
//    cell.textLabel.text=[self.Items objectAtIndex:indexPath.row];
//    cell.imageView.backgroundColor=[UIColor greenColor];
//    cell.imageView.bounds=CGRectMake(0, 0, 10, 10);
//    cell.imageView.image =[UIImage imageNamed:@"image.png"];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        btn.frame=CGRectMake(0, 2,cell.frame.size.width,CELL_H_PHONE-2);
        chkimg.frame=CGRectMake(0,(CELL_H_PHONE-16)/2 ,15,15);
        menu_lbl.frame=CGRectMake(chkimg.frame.size.width+5, (CELL_H_PHONE-22)/2,self.frame.size.width-chkimg.frame.size.width, 22);

    }
    else{
        btn.frame=CGRectMake(0, 2,cell.frame.size.width,CELL_H_PAD);
        
        chkimg.frame=CGRectMake(0,(CELL_H_PAD-16)/2 ,30,30);
        menu_lbl.frame=CGRectMake(chkimg.frame.size.width+5, (CELL_H_PAD-22)/2,self.frame.size.width-chkimg.frame.size.width, 30);

    }
    //btn.backgroundColor=[UIColor greenColor];
    if (indexPath.row ==((long)self.group-444))
    {
        [chkimg setImage:[UIImage imageNamed:@"sharing_group_circle_checked.png"]];
    
    }
    else
    {
      [chkimg setImage:[UIImage imageNamed:@"sharing_group_circle_unchecked.png"]];
        
    }
    
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    
    [cell.contentView addSubview:menu_lbl];
    [cell.contentView addSubview:chkimg];
    [cell.contentView addSubview:btn];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor colorWithRed:CREAME_R green:CREAME_G blue:CREAME_B alpha:1.0]];
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        return CELL_H_PAD;
    }
    else{
        return CELL_H_PHONE;
    }
}
-(void)radioGroupCheck:sender
{
    UIButton *btn=(UIButton *)sender;
    self.group=btn.tag;
    NSLog(@"Send group==== %ld",(long)self.group);
    [self.optTableView reloadData];
    
   
}



@end

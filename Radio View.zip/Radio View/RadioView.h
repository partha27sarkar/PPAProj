//
//  RadioView.h
//  BoJio
//
//  Created by KMI-IOS1 on 08/09/15.
//  Copyright (c) 2015 kminfosystems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BojioConstant.h"

@interface RadioView : UIView  <UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) UITableView *optTableView;
@property (strong, nonatomic) NSMutableArray *Items;
@property NSInteger group;


@end
